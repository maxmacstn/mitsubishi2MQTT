# THIS LIBRARY DOES NOT SUPPORT HOME ASSISTANT. 


## PLEASE REVIEW THESE LINKS FOR THIS INTEGRATION


https://github.com/unixko/MitsuCon 

https://github.com/dzungpv/mitsubishi2MQTT

https://gist.github.com/kmdm/29f740e5f36036fb23daba8f2109c359

https://github.com/gysmo38/mitsubishi2MQTT


### see #138 for more info... do not open issues regarding home assistant, I do not support it nor know anything about it. Use the gitter chat, if you need help!

