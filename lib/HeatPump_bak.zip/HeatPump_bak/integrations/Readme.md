Note: integrations are just example code. They are not a part of the library. I personally have no use for them, nor understand them.
If you have issues with these examples, I suggest you join the gitter chat and ask for help there. someone in the chat can help.

do not open issues for non library related issues!

Here is a link for Domoticz MQTT plugin
https://github.com/Masurov/Domoticz-MitsubishiHpMQTT-Plugin/
